const ESCALERAS = { 3: 22, 8: 31, 15: 44, 20: 41, 36: 57, 51: 72, 67: 86, 80: 99 };
const SERPIENTES = { 98: 78, 92: 71, 64: 44, 55: 35, 48: 26, 30: 11, 73: 53 };
const JUGADORES = [{ nombre: 'Jugador 1', ficha: '🐻' }, { nombre: 'Jugador 2', ficha: '🦊' }];

const $ = (s) => document.querySelector(s);
const pos = [1, 1];
let turno = 0, ocupado = false, temporizador = null;
let plato = [];
try { plato = JSON.parse(localStorage.getItem('plato')) || []; } catch (e) {}

const recetaDe = (n) => (n % 3 === 0 && n < 100 ? RECETAS[(n / 3 - 1) % RECETAS.length] : null);
const pausa = (ms) => new Promise((r) => setTimeout(r, ms));

function centro(n) {
  const f = Math.floor((n - 1) / 10);
  let c = (n - 1) % 10;
  if (f % 2) c = 9 - c;
  return { x: c * 10 + 5, y: (9 - f) * 10 + 5 };
}

function dibujarTablero() {
  const t = $('#tablero');
  for (let fila = 0; fila < 10; fila++) {
    for (let c = 0; c < 10; c++) {
      const f = 9 - fila;
      const n = f * 10 + (f % 2 ? 9 - c : c) + 1;
      const r = recetaDe(n);
      const d = document.createElement('div');
      d.className = 'casilla' + (r ? ' veg' : '');
      d.dataset.n = n;
      d.innerHTML = `<span class="num">${n}</span>${r ? `<span class="emoji">${r.emoji}</span>` : ''}<span class="fichas"></span>`;
      t.appendChild(d);
    }
  }
  const NS = 'http://www.w3.org/2000/svg';
  const svg = $('#lineas');
  for (const [a, b] of Object.entries(ESCALERAS)) {
    const p = centro(+a), q = centro(b);
    const l = document.createElementNS(NS, 'line');
    l.setAttribute('x1', p.x); l.setAttribute('y1', p.y);
    l.setAttribute('x2', q.x); l.setAttribute('y2', q.y);
    l.setAttribute('class', 'escalera');
    svg.appendChild(l);
  }
  for (const [a, b] of Object.entries(SERPIENTES)) {
    const p = centro(+a), q = centro(b);
    const mx = (p.x + q.x) / 2 + 8, my = (p.y + q.y) / 2;
    const s = document.createElementNS(NS, 'path');
    s.setAttribute('d', `M${p.x},${p.y} Q${mx},${my} ${q.x},${q.y}`);
    s.setAttribute('class', 'serpiente');
    svg.appendChild(s);
    const h = document.createElementNS(NS, 'circle');
    h.setAttribute('cx', p.x); h.setAttribute('cy', p.y); h.setAttribute('r', 1.8);
    h.setAttribute('class', 'cabeza');
    svg.appendChild(h);
  }
}

function pintarFichas() {
  document.querySelectorAll('.fichas').forEach((e) => (e.textContent = ''));
  pos.forEach((n, i) => {
    document.querySelector(`.casilla[data-n="${n}"] .fichas`).textContent += JUGADORES[i].ficha;
  });
}

function pintarPlato() {
  $('#plato').textContent = plato.join(' ');
  $('#platoVacio').hidden = plato.length > 0;
}

function mensaje(t) { $('#mensaje').textContent = t; }
function pintarTurno() { $('#turno').textContent = `Turno de ${JUGADORES[turno].ficha} ${JUGADORES[turno].nombre}`; }

async function tirar() {
  if (ocupado) return;
  ocupado = true;
  const dado = 1 + Math.floor(Math.random() * 6);
  $('#dadoValor').textContent = dado;
  mensaje('');
  const meta = Math.min(100, pos[turno] + dado);
  while (pos[turno] < meta) { pos[turno]++; pintarFichas(); await pausa(250); }

  const n = pos[turno];
  if (n === 100) { mensaje(`${JUGADORES[turno].nombre} llegó a la cocina. ¡Ganó!`); return; }
  if (ESCALERAS[n]) { await pausa(300); pos[turno] = ESCALERAS[n]; mensaje('¡Escalera! Subes.'); pintarFichas(); }
  else if (SERPIENTES[n]) { await pausa(300); pos[turno] = SERPIENTES[n]; mensaje('¡Serpiente! Bajas.'); pintarFichas(); }

  const r = recetaDe(pos[turno]);
  if (r) { abrirReceta(r); return; }
  siguiente();
}

function siguiente() {
  turno = (turno + 1) % JUGADORES.length;
  pintarTurno();
  ocupado = false;
}

/* ---------- Receta ---------- */
function cerrarModal() {
  clearInterval(temporizador);
  speechSynthesis.cancel();
  $('#modal').hidden = true;
  siguiente();
}

function abrirReceta(r) {
  const caja = $('.modal-tarjeta');
  caja.innerHTML = `
    <div class="grande">${r.emoji}</div>
    <h2 id="modalTitulo">${r.vegetal}</h2>
    <h3>${r.nombre}</h3>
    <p class="etiqueta">${r.fuego}</p>
    <p><strong>Ingredientes:</strong> ${r.ingredientes.join(', ')}</p>
    <ol>${r.pasos.map((p) => `<li>${p}</li>`).join('')}</ol>
    <p class="aviso">Pide ayuda a un adulto para cuchillos y estufa. Lava bien las manos y los alimentos.</p>
    <div class="fila">
      <button class="btn sec" id="oir">Escuchar</button>
      <button class="btn" id="cocinar">¡Cocinar!</button>
    </div>
    <button class="btn sec" id="seguir">Guardar y seguir</button>`;
  $('#modal').hidden = false;
  $('#oir').onclick = () => {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(`${r.nombre}. Ingredientes: ${r.ingredientes.join(', ')}. ${r.pasos.join('. ')}.`);
    u.lang = 'es-ES';
    speechSynthesis.speak(u);
  };
  $('#cocinar').onclick = () => modoCocinar(r);
  $('#seguir').onclick = () => guardar(r);
}

function guardar(r) {
  if (!plato.includes(r.emoji)) plato.push(r.emoji);
  try { localStorage.setItem('plato', JSON.stringify(plato)); } catch (e) {}
  pintarPlato();
  cerrarModal();
}

function modoCocinar(r) {
  const caja = $('.modal-tarjeta');
  caja.innerHTML = `
    <div class="grande">${r.emoji}</div>
    <h2 id="modalTitulo">${r.nombre}</h2>
    <ul class="pasos">${r.pasos.map((p, i) => `<li><label><input type="checkbox" data-i="${i}"> ${p}</label></li>`).join('')}</ul>
    ${r.min ? '<button class="btn" id="tiempo"></button>' : ''}
    <button class="btn sec" id="volver">Volver</button>`;
  if (r.min) {
    let seg = r.min * 60;
    const b = $('#tiempo');
    const pintar = () => (b.textContent = `${Math.floor(seg / 60)}:${String(seg % 60).padStart(2, '0')} · toca para saltar`);
    pintar();
    temporizador = setInterval(() => { seg--; if (seg <= 0) { clearInterval(temporizador); b.textContent = '¡Listo!'; } else pintar(); }, 1000);
    b.onclick = () => { clearInterval(temporizador); seg = 0; b.textContent = '¡Listo!'; };
  }
  $('#volver').onclick = () => { clearInterval(temporizador); abrirReceta(r); };
  caja.addEventListener('change', () => {
    if ([...caja.querySelectorAll('input')].every((i) => i.checked)) {
      const fin = document.createElement('button');
      fin.className = 'btn'; fin.textContent = 'Guardar en mi plato';
      fin.onclick = () => guardar(r);
      if (!caja.querySelector('.btn:not(.sec):last-child[data-fin]')) { fin.dataset.fin = 1; caja.insertBefore(fin, $('#volver')); }
    }
  });
}

dibujarTablero();
pintarFichas();
pintarPlato();
pintarTurno();
$('#dado').addEventListener('click', tirar);
