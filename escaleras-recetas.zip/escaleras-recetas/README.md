# Escaleras, serpientes y recetas

Juego de escaleras y serpientes para dos jugadores. Cada 3 casillas hay un vegetal con una receta sencilla
pensada para madres y padres que no saben cómo usar ciertos ingredientes.

## Cómo se juega
1. Tira el dado y avanza.
2. Si caes en un vegetal se abre su receta: escúchala, cocínala paso a paso o guárdala en tu plato.
3. Escaleras suben, serpientes bajan. Gana quien llegue primero a la casilla 100.

## Estructura
```
index.html      # Página y contenedores
css/styles.css  # Estilos
js/data.js      # Recetas (aquí agregas más)
js/game.js      # Tablero, dado, turnos, modal de receta
```

## Agregar recetas
Edita `js/data.js` y añade un objeto con `emoji`, `vegetal`, `nombre`, `fuego`, `min`, `ingredientes` y `pasos`.
Las recetas se asignan en orden a las casillas 3, 6, 9... y se repiten al terminar la lista.

## Publicar en GitHub Pages
Settings → Pages → Branch `main` → carpeta `/ (root)`.
